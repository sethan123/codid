package login.submit.registration;

import java.sql.Connection;
import java.sql.DriverManager;

public class Myconnectionprovider implements myprovider 
{
	static Connection con=null;
	public static Connection getcon()
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");//com.mysql.jdbc.Driver
			con=DriverManager.getConnection(connUrl,"root","root");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
}
