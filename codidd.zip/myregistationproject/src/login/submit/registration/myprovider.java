package login.submit.registration;

public interface myprovider 

{
	String username="root";
	String pwd="root";
	String connUrl="jdbc:mysql://localhost:3306/data?characterEncoding=latin1";
}
