package login.submit.registration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerDOAImpl implements CustomerDAO {
	static  Connection con;//connecting the sql
	static PreparedStatement ps;//it will prepared the query
	
	@Override
	public int insertCustomer(customer c)

	{
		int status = 0;
		try
		{
			con=Myconnectionprovider.getcon();
			ps=con.prepareStatement("insert into customer valued(?,?)");
			ps.setNString(1,c.getUsername());//pass the perimeter
			ps.setString(2,c.getPassword());
			ps.setString(3,c.getPassword());
			status=ps.executeUpdate();
			con.close();
			
			
			
			
		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	@Override
	public customer getCustomer(String userid, String pass) {
		customer c=new customer();
		try 
		{
			con=Myconnectionprovider.getcon();
			ps=con.prepareStatement("select * from customer where userid=? and password=?");
			ps.setString(1,userid);
			ps.setString(2,pass);
			///result set
			ResultSet rs=ps.executeQuery();
			while(rs.next());//while looop
			{
			c.setUsername(rs.getString(1));
			c.setPassword(rs.getString(2));
			c.setName(rs.getNString(3));
			}
			
		} catch (Exception e) {
			System.out.println(e);
		}

		return c;
	}

}
