//create 2 method one is providing click login get details and another method to feed data when registration is called

package login.submit.registration;

public interface CustomerDAO
{
	public int insertCustomer(customer c);
	public customer  getCustomer(String username,String pass);
}