//this form ois submissiopn of login registation

package login.submit.registration;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialException;


@WebServlet("/loginRegister")
public class LoginRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public LoginRegister() 
    {
            
    }
    protected void dopost(HttpServletRequest request,HttpServletResponse response) throws SerialException,IOException, ServletException
    {
    	CustomerDAO cd=new CustomerDOAImpl();
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String submitType=request.getParameter("submit");
		customer c=cd.getCustomer(username, password);
		
		if(submitType.contentEquals("login") && c!=null && c.getName()!=null)///if the data is not found 
		{
		request.setAttribute("message", c.getName());
		request.getRequestDispatcher("welcome.jsp").forward(request, response);
		
			
		}
		else if(submitType.equals("Register"))///provide to method through assign the database 
		{
			c.setName(request.getParameter("name"));
			c.setPassword(password);
			c.setUsername(username);
			cd.insertCustomer(c);

			request.setAttribute("successmessage", "Regisattion done please login to countinue!!");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		
			}
		else
		{
			request.setAttribute("message", "data not found ,click on register!!");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
    	
		}
    	
    	
    	
    	
	}


